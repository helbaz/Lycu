# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Categoria, Comentari, Curiositat, Vots

admin.site.register(Categoria),
admin.site.register(Comentari),
admin.site.register(Curiositat)
admin.site.register(Vots),
