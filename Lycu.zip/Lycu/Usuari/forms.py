from django import forms
from django.forms import ModelForm
from Usuari.models import *
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class ExtendsUserCreationForm(UserCreationForm):

    class Meta:
        model=User
        field = ('username', 'password1', 'password2')

    def save(self, commit=True):
        user = super(ExtendsUserCreationForm, self).save(commit=False)


        if commit:
            user.save()
        return user

class Perfil_Usuari(forms.ModelForm):
    class Meta:
        model = Usuaris
        fields = ('correu', 'imatge_perfil')
