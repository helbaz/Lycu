$(document).ready(function(){ 
  
    $("#username").attr("placeholder", "Usuari");
    $("#password").attr("placeholder", "Constrassenya");
    
    $( "#username" ).addClass( "form-control" );
    $( "#password" ).addClass( "form-control" );
})