$(document).ready(function(){ 
  
    $("#id_username").attr("placeholder", "Usuari");
    $("#id_password").attr("placeholder", "Constrassenya");
    
    $( "#id_username" ).addClass( "form-control" );
    $( "#id_password" ).addClass( "form-control" );
})