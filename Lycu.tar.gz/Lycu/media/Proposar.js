﻿/*Añade classes y placeholdes al cargar la pagina*/
$(document).ready(function () {
            $("#id_titol").attr("placeholder", "Titol");
            $("#id_contingut").attr("placeholder", "Contingut");
            $("#id_imatge").attr("placeholder", "Contrasenya");
            $("#id_categoria").attr("placeholder", "Confirma contrasenya");

            $("input").addClass("form-control");
            $(".submit").css("width","70px")
            $(".submit").css("margin","auto")

        })