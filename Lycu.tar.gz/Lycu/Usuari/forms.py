from django import forms
from Usuari.models import Usuaris
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class registrarUsuari(UserCreationForm):
    correu = forms.EmailField()
    imatge = forms.ImageField(required=False)

    class Meta:
        model = User
        fields = ('username', 'password1', 'password2')


class creacio_usuari(forms.ModelForm):
    class Meta:
        model = Usuaris
        fields = ('correu', 'imatge_perfil')
