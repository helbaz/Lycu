from django import forms
from Usuari.models import Usuaris
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class ExtendsUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'password1', 'password2')

    def save(self, commit=True):
        user = super(ExtendsUserCreationForm, self).save(commit=False)

        if commit:
            user.save()
        return user


class creacio_usuari(forms.ModelForm):
    class Meta:
        model = Usuaris
        fields = ('correu', 'imatge_perfil')
