# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from .forms import *


# Create your views here.
def registre(request):
    if request.method == 'POST':
        form = ExtendsUserCreationForm(request.POST)
        profile_form = creacio_usuari(request.POST)
        if form.is_valid() and profile_form.is_valid():
            usuari = form.save()
            perfil = profile_form.save(commit=False)
            perfil.usuari = usuari
            perfil.save()
            nom_usuari = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            usuari = authenticate(username=nom_usuari, password=password)
            login(request, usuari)
            return redirect('Registra.html')
        else:
            form = ExtendsUserCreationForm()
            profile_form = creacio_usuari()
        context = {'form': form, 'profile_form': profile_form}
        return render(request, 'Registra.html', context)
