from django import forms

#class formulariPublicacio(forms.Form):
