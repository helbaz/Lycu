# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.decorators import login_required

from Usuari.models import *
from django.shortcuts import render

from .models import *


# Create your views here.
def index(request):
    curiositats = Curiositat.objects.filter(estat=2).order_by('-data')[0]
    context = {'curiositat': curiositats,
               'css': '../media/Index.css'}
    if request.user.is_authenticated():
        usuari = Usuaris.objects.get(usuari=request.user)
        context = {'curiositat': curiositats, 'nom_usuari': request.user.username, 'css': '../media/Index.css',
                   'usuari': usuari}
    return render(request, 'Index.html', context)

#@login_required
#def publicar(request):
