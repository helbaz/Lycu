# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.urls import reverse

from Usuari.models import *
from LycuMain.models import *
from django.shortcuts import render
from .forms import *

from .models import *


# Create your views here.
def index(request):
    curiositats = Curiositat.objects.filter(estat=2).order_by('-data')[0]
    context = {'curiositat': curiositats,
               'css': '../media/Index.css'}
    if request.user.is_authenticated():
        usuari = Usuaris.objects.get(usuari=request.user)
        context = {'curiositat': curiositats, 'nom_usuari': request.user.username, 'css': '../media/Index.css',
                   'usuari': usuari}
    return render(request, 'Index.html', context)


# @login_required
# def publicar(request):

@login_required()
def publicarCuriositat(request):
    form = formulariCuriositat(request.POST, request.FILES)
    if request.method == 'POST':
        if form.is_valid():
            # form.save(commit=False)
            titol = form.cleaned_data.get('titol')
            contingut = form.cleaned_data.get('contingut')
            imatge = form.cleaned_data.get('imatge')
            curiositat = Curiositat(titol=titol, imatge=imatge, contingut=contingut, estat=2)
            curiositat.save()
            return HttpResponseRedirect(reverse('Index'))
    context = {'formulari': form}
    return render(request, 'Proposar.html', context)

@login_required()
def crearCategoria(request):
    if request.method == 'POST':
        nom = request.POST['categoria']
        categoria = Categoria(nom=nom)
        categoria.save()
        return HttpResponseRedirect(reverse('Index'))
    context = {'formulari': form}
    return render(request, 'Proposar.html', context)